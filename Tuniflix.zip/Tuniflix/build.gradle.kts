plugins {
    id("cloudstream-plugin")
}

cloudstream {
    description = "Extension Tuniflix pour Cloudstream"
    language = "kotlin"
    authors = listOf("raedkebaili")
    status = 1
}

dependencies {
}
